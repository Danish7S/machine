"""Generates a sample dataset of machine sensor readings (based on the rules of the
AI4I 2020 predictive maintenance dataset) for demonstration."""
import math
import random
import app

OSF_LIMIT = {"L": 11000, "M": 12000, "H": 13000}


def label(t, air, proc, rpm, torque, wear):
    power = torque * rpm * 2 * math.pi / 60
    if wear * torque > OSF_LIMIT[t]:
        return "Overstrain"
    if power < 3500 or power > 9000:
        return "Power Failure"
    if proc - air < 8.6 and rpm < 1380:
        return "Heat Dissipation"
    if wear > 232:
        return "Tool Wear"
    return "No Failure"


def records(n=5000, seed=3):
    rnd = random.Random(seed)
    for i in range(1, n + 1):
        t = rnd.choices(["L", "M", "H"], [0.6, 0.3, 0.1])[0]
        air = round(rnd.gauss(300, 2), 1)
        proc = round(air + rnd.gauss(10.2, 1.0), 1)
        rpm = int(min(2890, max(1170, rnd.gauss(1540, 180))))
        torque = round(min(77, max(4, 40 - (rpm - 1540) * 0.035 + rnd.gauss(0, 6.5))), 1)
        wear = rnd.randint(0, 240)
        yield (f"MC-{i:04d}", t, air, proc, rpm, torque, wear, label(t, air, proc, rpm, torque, wear))


if __name__ == "__main__":
    app.init_db()
    conn = app.get_db()
    conn.executemany("INSERT INTO readings (machine_id, machine_type, air_temp, process_temp, rpm, "
                     "torque, tool_wear, failure_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", list(records()))
    conn.commit()
    conn.close()
    print("Inserted sample sensor readings")
