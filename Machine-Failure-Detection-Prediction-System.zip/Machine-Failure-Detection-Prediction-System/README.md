# Machine Failure Detection Prediction System

DevOps & Agile Methodologies (23AD52C) mini project - DANISH SELVA S (24243003), AI & DS, National Engineering College.

A Flask web app that stores machine sensor readings (air temperature, process temperature, rotational speed,
torque and tool wear), trains a Random Forest classifier to detect machine failures and their type
(Heat Dissipation, Power, Overstrain, Tool Wear), and predicts the failure risk of a machine with a
recommended maintenance action.

## Run
    pip install -r requirements.txt
    python seed_data.py      # loads 5000 sample sensor readings
    python app.py            # http://localhost:5000  (admin / admin123)

## Test
    pytest -v

## Docker
    docker compose up --build
