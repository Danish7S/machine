from flask import Flask, render_template, request, redirect, url_for, session, flash
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import numpy as np
import sqlite3

app = Flask(__name__)
app.secret_key = "devops-mini-project-secret"
DB = "machine.db"
TYPES = {"L": 0, "M": 1, "H": 2}                      # machine quality variant
FEATURES = ["machine_type", "air_temp", "process_temp", "rpm", "torque",
            "tool_wear", "temp_diff", "power_kw"]
FAILURES = ["No Failure", "Heat Dissipation", "Power Failure", "Overstrain", "Tool Wear"]
ACTIONS = {"No Failure": "Machine is healthy - continue normal operation",
           "Heat Dissipation": "Check cooling system and clean air filters",
           "Power Failure": "Adjust spindle speed / torque to keep power in range",
           "Overstrain": "Reduce load and replace the cutting tool",
           "Tool Wear": "Schedule tool replacement immediately"}
MODEL = {}


def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute("""CREATE TABLE IF NOT EXISTS readings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        machine_id TEXT NOT NULL,
        machine_type TEXT NOT NULL,
        air_temp REAL NOT NULL,
        process_temp REAL NOT NULL,
        rpm INTEGER NOT NULL,
        torque REAL NOT NULL,
        tool_wear INTEGER NOT NULL,
        failure_type TEXT,
        predicted TEXT
    )""")
    conn.commit()
    conn.close()


def make_features(r):
    """Sensor values plus two engineered features: temperature difference and power."""
    power_kw = r["torque"] * r["rpm"] * 2 * np.pi / 60 / 1000
    return [TYPES[r["machine_type"]], r["air_temp"], r["process_temp"], r["rpm"],
            r["torque"], r["tool_wear"], round(r["process_temp"] - r["air_temp"], 2),
            round(power_kw, 3)]


def train_model(rows):
    X = np.array([make_features(r) for r in rows], dtype=float)
    y = np.array([r["failure_type"] for r in rows])
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, stratify=y, random_state=42)
    clf = RandomForestClassifier(n_estimators=200, class_weight="balanced", random_state=42)
    clf.fit(X_tr, y_tr)
    pred = clf.predict(X_te)
    fail_true, fail_pred = y_te != "No Failure", pred != "No Failure"
    labels = [f for f in FAILURES if f in set(y)]
    metrics = {"accuracy": round(accuracy_score(y_te, pred) * 100, 2),
               "precision": round(precision_score(fail_true, fail_pred) * 100, 2),
               "recall": round(recall_score(fail_true, fail_pred) * 100, 2),
               "f1": round(f1_score(fail_true, fail_pred) * 100, 2),
               "train_rows": len(y_tr), "test_rows": len(y_te)}
    importance = sorted(zip(FEATURES, clf.feature_importances_), key=lambda t: -t[1])
    MODEL.update(model=clf, metrics=metrics, labels=labels,
                 matrix=confusion_matrix(y_te, pred, labels=labels).tolist(),
                 importance=[(f, round(float(v) * 100, 1)) for f, v in importance])
    return metrics


def predict_failure(r):
    clf = MODEL["model"]
    probs = clf.predict_proba([make_features(r)])[0]
    best = int(np.argmax(probs))
    no_fail = list(clf.classes_).index("No Failure")
    return {"type": clf.classes_[best], "confidence": round(float(probs[best]) * 100, 1),
            "risk": round((1 - float(probs[no_fail])) * 100, 1)}


def ensure_model(conn):
    if not MODEL:
        rows = conn.execute("SELECT * FROM readings WHERE failure_type IS NOT NULL").fetchall()
        if len(rows) < 100:
            return False
        train_model(rows)
    return True


def logged_in():
    return session.get("logged_in")


def read_form(form):
    return {"machine_type": form["machine_type"], "air_temp": float(form["air_temp"]),
            "process_temp": float(form["process_temp"]), "rpm": int(form["rpm"]),
            "torque": float(form["torque"]), "tool_wear": int(form["tool_wear"])}


@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form["username"] == "admin" and request.form["password"] == "admin123":
            session["logged_in"] = True
            return redirect(url_for("dashboard"))
        flash("Invalid username or password")
    return render_template("login.html")


@app.route("/dashboard")
def dashboard():
    if not logged_in():
        return redirect(url_for("login"))
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) FROM readings").fetchone()[0]
    by_type = conn.execute("SELECT failure_type, COUNT(*) AS n FROM readings WHERE failure_type "
                           "IS NOT NULL AND failure_type != 'No Failure' GROUP BY failure_type "
                           "ORDER BY n DESC").fetchall()
    points = conn.execute("SELECT rpm, torque, failure_type FROM readings "
                          "WHERE failure_type IS NOT NULL LIMIT 1500").fetchall()
    ready = ensure_model(conn)
    conn.close()
    failures = sum(r["n"] for r in by_type)
    return render_template("dashboard.html", total=total, failures=failures, by_type=by_type,
                           points=points, metrics=MODEL.get("metrics") if ready else None)


@app.route("/readings", methods=["GET", "POST"])
def readings():
    if not logged_in():
        return redirect(url_for("login"))
    conn = get_db()
    if request.method == "POST":
        try:
            r = read_form(request.form)
            result = predict_failure(r)["type"] if ensure_model(conn) else None
            conn.execute(
                "INSERT INTO readings (machine_id, machine_type, air_temp, process_temp, rpm, "
                "torque, tool_wear, predicted) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (request.form["machine_id"], r["machine_type"], r["air_temp"],
                 r["process_temp"], r["rpm"], r["torque"], r["tool_wear"], result))
            conn.commit()
            flash(f"Reading saved - predicted status: {result or 'model not trained'}")
        except (ValueError, KeyError):
            flash("Enter valid sensor values")
    rows = conn.execute("SELECT * FROM readings ORDER BY id DESC LIMIT 16").fetchall()
    conn.close()
    return render_template("readings.html", rows=rows)


@app.route("/train")
def train():
    if not logged_in():
        return redirect(url_for("login"))
    conn = get_db()
    rows = conn.execute("SELECT * FROM readings WHERE failure_type IS NOT NULL").fetchall()
    conn.close()
    if len(rows) < 100:
        flash("At least 100 labelled readings are needed to train the model")
        return redirect(url_for("readings"))
    train_model(rows)
    return render_template("train.html", m=MODEL["metrics"], labels=MODEL["labels"],
                           matrix=MODEL["matrix"], importance=MODEL["importance"])


@app.route("/predict", methods=["GET", "POST"])
def predict():
    if not logged_in():
        return redirect(url_for("login"))
    conn = get_db()
    ready = ensure_model(conn)
    conn.close()
    result = None
    if request.method == "POST":
        if ready:
            result = predict_failure(read_form(request.form))
            result["action"] = ACTIONS[result["type"]]
        else:
            flash("Train the model first")
    return render_template("predict.html", result=result, form=request.form)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
