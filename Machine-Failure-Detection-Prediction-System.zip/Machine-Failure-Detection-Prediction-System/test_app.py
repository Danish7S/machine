import pytest
import app as mf_app
import seed_data

HEALTHY = {"machine_type": "M", "air_temp": 300.0, "process_temp": 310.5, "rpm": 1550,
           "torque": 40.0, "tool_wear": 60}
OVERSTRAIN = dict(HEALTHY, machine_type="L", torque=55.0, tool_wear=220)


@pytest.fixture
def client(tmp_path):
    mf_app.DB = str(tmp_path / "test.db")
    mf_app.MODEL.clear()
    mf_app.app.config["TESTING"] = True
    mf_app.init_db()
    conn = mf_app.get_db()
    conn.executemany("INSERT INTO readings (machine_id, machine_type, air_temp, process_temp, rpm, "
                     "torque, tool_wear, failure_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                     list(seed_data.records(3000)))
    conn.commit()
    conn.close()
    with mf_app.app.test_client() as c:
        yield c


def login(c):
    return c.post("/", data={"username": "admin", "password": "admin123"}, follow_redirects=True)


def test_engineered_features():
    f = mf_app.make_features(HEALTHY)
    assert f[0] == 1 and f[6] == 10.5 and 6.4 < f[7] < 6.6


def test_login_success_and_failure(client):
    assert b"Dashboard" in login(client).data
    bad = client.post("/", data={"username": "x", "password": "y"}, follow_redirects=True)
    assert b"Invalid username or password" in bad.data


def test_protected_page_redirects(client):
    assert client.get("/predict").status_code == 302


def test_model_accuracy(client):
    login(client)
    assert client.get("/train").status_code == 200
    assert mf_app.MODEL["metrics"]["accuracy"] > 90


def test_prediction_healthy_and_failure(client):
    login(client)
    client.get("/train")
    assert mf_app.predict_failure(HEALTHY)["type"] == "No Failure"
    assert mf_app.predict_failure(OVERSTRAIN)["type"] == "Overstrain"
    res = client.post("/predict", data=OVERSTRAIN)
    assert b"FAILURE LIKELY" in res.data
